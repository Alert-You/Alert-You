-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: k7b109.p.ssafy.io    Database: alertyou
-- ------------------------------------------------------
-- Server version	8.0.31-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_id` bigint NOT NULL AUTO_INCREMENT,
  `active` bit(1) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `school_id` bigint DEFAULT NULL,
  `fcm_token` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  KEY `FKhbkxju61kpht7qnnhemgjv3u7` (`school_id`),
  CONSTRAINT `FKhbkxju61kpht7qnnhemgjv3u7` FOREIGN KEY (`school_id`) REFERENCES `school` (`school_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,_binary '','$2a$10$CLMmRmrUn.Jwe/w0i7k7Ce5JbhnLB5zbvQNllV4CzFvi8zpnIp.A2','01029128780','학생','김애리',1,NULL),(2,_binary '','$2a$10$rb.2ZiEgvYIqxxp1uG./eeS12TlgIkqWkYb8QxgKIxuNjEcpDLobO','01092458873','학생','박시원',1,'dXPOIuRdTTCPJHNwsqI1ZF:APA91bGqyfRUsjTMhoLBYD1YcFne0_G-XO5B_YU_QNUxFPROY10RFxHVLkGPl7X8_pxZTpOvOrtVowY0bHTr3IRt10dSM_RzYUxfvG551P6mg4g7JvuTWKph69lfdwhhzDqYFhQfsMyH'),(3,_binary '','$2a$10$l/LTT3AKxOYlxpS5LVPwYe1A9X1dlcIOQ3W0NgN9sOW6Mcjo.eude','01085500751','학생','박승훈',1,'c9UfoAnuRP2cjCBc-dCyNo:APA91bEGVJSPop9h0e-yczED0wlj4IaokZtIDACW6PSSEfdDPyBFDyz1585lnPlNnA1QO8ryvhrJKrQ7sIQ7rU2QbD9USeQFw4jpvLknWdC-UNyIdWgN8FDsTQzrgRc7XTkS4gwczDVS'),(4,_binary '','$2a$10$a5tU4xhwacmp0/Dc73U3wurHa5y9vv2K.XYMQw7j6DE76zY.PKNQq','01022420407','학생','이원우',1,'fnM3CDCOTES3L33ly8TyXZ:APA91bHl0yN2IpSD9zkEiXMc7wdKjePdIjWW74I3x1eAu5P3zZMPUo8o2B-UQRIreZYKand1cqeQAtPv6lJzhsdcsfWZKR7_SoqK7zVLw5svcz-kpM8xEcyG7dGxfW-flPFQEr47q8th'),(5,_binary '','$2a$10$ItdDWP3jvU8fI2PbUvmjjOldVvvOJmKxQCkwLwR9MfmewndcSJyFG','01032318412','교사','송상진',1,'eH32QxgKSHicIuzfsMUIBN:APA91bEiIubYDpA8MHW-YF0CRtvP5HHGBinyTR5SfFv2urnIDrICKQMLY_LPBn_io7wZhHsXqBQcu_4hTSU1EI4FNzke-sKhI3-XVVqIVl7AwqfJvy5HIgxza0bBzdvzsXr3PRHHRebm');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-18 17:12:15
